Clone/compile/patch with any options but models

copy and replace /src after copying over SGIv1.4